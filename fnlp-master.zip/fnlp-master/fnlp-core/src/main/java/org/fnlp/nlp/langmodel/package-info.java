/**
 * 
 */
/**
 * @author xpqiu
 *
 */
package org.fnlp.nlp.langmodel;