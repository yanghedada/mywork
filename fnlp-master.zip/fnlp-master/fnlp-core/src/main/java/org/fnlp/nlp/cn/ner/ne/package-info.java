/**
 * 
 */
/**
 * @author Xipeng
 *
 */
package org.fnlp.nlp.cn.ner.ne;