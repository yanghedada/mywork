/**
 * 
 */
/**
 * @author Xipeng
 *
 */
package org.fnlp.nlp.langmodel.lda;