/**
 * FNLP数据内部格式
 * @author Xipeng
 *
 */
package org.fnlp.nlp.corpus.fnlp;