/**
 * 
 */
/**
 * @author Xipeng
 *
 */
package org.fnlp.nlp.similarity.train;