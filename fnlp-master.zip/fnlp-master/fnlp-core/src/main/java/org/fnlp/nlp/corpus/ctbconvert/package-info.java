/**
 * CTB树库转换
 */
package org.fnlp.nlp.corpus.ctbconvert;