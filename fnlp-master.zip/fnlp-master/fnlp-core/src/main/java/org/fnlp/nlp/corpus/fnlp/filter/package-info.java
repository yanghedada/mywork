/**
 * 
 */
/**
 * @author Xipeng
 *
 */
package org.fnlp.nlp.corpus.fnlp.filter;